Instructions:
1. Navigate to the directory that contains main.c, header.h, and your .csv file of movies
2. Enter "gcc --std=gnu99 -o movies main.c" on the commandline
3. After running that a "movies" executable file should be created inside the directory
4. Enter "./movies movies_sample_1.csv" or "./movies (your file).csv" on the commandline
5. Navigate the program.